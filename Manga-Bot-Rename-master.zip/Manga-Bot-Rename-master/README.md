<p align="center">
    <a href="https://github.com/Dra-Sama/mangabot">
        <kbd>
            <img width="250" src="https://te.legra.ph/file/d55e3cdf8a5d3eb8318e7.jpg" alt="Manga Bot">
        </kbd>
    </a>
</p>

<p align="center">
<div align=center>
<p align="center">
<div align=center>

[![GitHub forks](https://img.shields.io/github/forks/Dra-Sama/mangabot?style=social)](https://github.com/weebzone/WZML/fork)
[![GitHub followers](https://img.shields.io/github/followers/Dra-sama?style=social&label=Dra-sama%20Followers)](https://github.com/Dra-sama)

----

[![](https://img.shields.io/github/repo-size/Dra-Sama/mangabot?color=green&label=Repo%20Size&labelColor=292c3b)](#) [![](https://img.shields.io/github/commit-activity/m/Dra-Sama/mangabot?logo=github&labelColor=292c3b&label=Github%20Commits)](#) [![](https://img.shields.io/github/license/Dra-Sama/mangabot?style=flat&label=License&labelColor=292c3b)](#)|[![](https://img.shields.io/github/issues-raw/Dra-Sama/mangabot?style=flat&label=Open%20Issues&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-closed-raw/Dra-Sama/mangabot?style=flat&label=Closed%20Issues&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-pr-raw/Dra-Sama/mangabot?style=flat&label=Open%20Pull%20Requests&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-pr-closed-raw/Dra-Sama/mangabot?style=flat&label=Closed%20Pull%20Requests&labelColor=292c3b)](#)
:---:|:---:|
[![](https://img.shields.io/github/languages/count/Dra-Sama/mangabot?style=flat&label=Total%20Languages&labelColor=292c3b&color=blueviolet)](#) [![](https://img.shields.io/github/languages/top/Dra-Sama/mangabot?style=flat&logo=python&labelColor=292c3b)](#) [![](https://img.shields.io/github/last-commit/Dra-Sama/mangabot?style=flat&label=Last%20Commit&labelColor=292c3b&color=important)](#) [![](https://badgen.net/github/branches/Dra-Sama/mangabot?label=Total%20Branches&labelColor=292c3b)](#)|[![](https://img.shields.io/github/forks/Dra-Sama/mangabot?style=flat&logo=github&label=Forks&labelColor=292c3b&color=critical)](#) [![](https://img.shields.io/github/stars/Dra-Sama/mangabot?style=flat&logo=github&label=Stars&labelColor=292c3b&color=yellow)](#) [![](https://badgen.net/docker/pulls/codewithweeb/Dra-sama?icon=docker&label=Pulls&labelColor=292c3b&color=blue)](#)
[![](https://img.shields.io/badge/Telegram%20Channel-Join-9cf?style=for-the-badge&logo=telegram&logoColor=blue&style=flat&labelColor=292c3b)](https://t.me/Wizard_bots) |[![](https://img.shields.io/badge/Support%20Group-Join-9cf?style=for-the-badge&logo=telegram&logoColor=blue&style=flat&labelColor=292c3b)](https://t.me/WizardBotHelper) |

</div>

----

 ## ***Manga Bot***

<div align=center>

ℹ️ A Powerful Pyrogram Based Telegram Manga Downloader.|
---|
    
### ***Source Code*** : [Repo](Dra-Sama/mangabot)

#### Note: `If you Like My Work, Give Stars ⭐ to the Repo and Follow Me on Github`
####    If You Want To Host Your Own Bot Then Change Your config.py File
    
----
</div>
</p>


### 1. [***Getting Started***](https://github.com/Dra-Sama/mangabot/wiki/Getting-Started)
Introduction To the Bot

### 2. [***Env Variables***](https://github.com/Dra-Sama/mangabot/wiki/Env-Variables)
Bot Variables

## 3. [***Deployment***](https://github.com/Dra-Sama/mangabot/wiki/Deployment)
Way of Deployment Bot

━━━━━━━━━━━━━━━━━━━━

<h3 align="center">
    ─「 ᴄʀᴇᴅɪᴛs 」─
</h3>

- <b>[Dra-Sama](https://github.com/Dra-sama)  ➻  [sᴏᴍᴇᴛʜɪɴɢ](https://github.com/Dra-sama/mangabot) </b>
- <b>[🍀 Daniel Rivero 🍅](https://github.com/driverog)  ➻  [tg-manga-bot](https://github.com/driverog/tg-manga-bot) </b>

<b>And All [The Contributors](https://github.com/Dra-sama/mangabot/graphs/contributors) Who Helped In Making Manga Bot Useful And Powerful 🖤 </b>

━━━━━━━━━━━━━━━━━━━━

